/* ==========================================================
   Vroz Studio — Font Shop
   Data yang paling sering diedit: fonts, pops, FREE, LIC, LT
   ========================================================== */
(function(){
  /* Replace this list with your fonts. "f" = the font-family name in CSS. */
  var fonts=[
    {n:'Sporter',t:'display',c:'Sports display',f:'Unbounded',p:'$21',desc:'Introducing our new product, Sporter, a sporty display typeface. Sporter is good for logotype, label, badge, headline, signature, packaging and more.'},
    {n:'Vroz Sans',t:'sans',c:'Sans serif',f:'Bricolage Grotesque',p:'$21'},
    {n:'Gridline',t:'sans',c:'Sans serif',f:'Bricolage Grotesque',p:'$21'},
    {n:'Bureno',t:'display',c:'Display',f:'Unbounded',p:'$21'},
    {n:'Moresto',t:'script',c:'Script',f:'Pacifico',p:'$21'},
    {n:'Lucky Saint',t:'script',c:'Handwritten',f:'Caveat',p:'$21'},
    {n:'Shaden',t:'brush',c:'Handwritten',f:'Permanent Marker',p:'$21'},
    {n:'Nuega',t:'serif',c:'Slab serif',f:'Fraunces',p:'$21'},
    {n:'Richale',t:'serif',c:'Script retro',f:'DM Serif Display',p:'$21'},
    {n:'Whimsy',t:'sans',c:'Playful',f:'Syne',p:'$21'},
    {n:'Easy Noise',t:'serif',c:'Display',f:'Instrument Serif',p:'$21'}
  ];
  var pops=[
    {n:'Comic Jungle',f:'Permanent Marker',d:'Playful, for kids'},
    {n:'Street Drips',f:'Syne',d:'Graffiti'},
    {n:'Golden Varsity',f:'Fraunces',d:'Collegiate and sports style'}
  ];
  var PAL=[['#054342','#F2E9D8'],['#2B3BFF','#FFFFFF'],['#F4C430','#14161C'],['#E8553D','#FFFFFF'],['#14161C','#EFF1F5'],['#CFE8E0','#054342'],['#F2D4DC','#5A1230'],['#1E2A5E','#F5F0E6'],['#C9D96A','#1F2A10']];
  function deco(i,c){
    var dots='';for(var r=0;r<5;r++)for(var k=0;k<5;k++)dots+='<circle cx="'+(58+k*8)+'" cy="'+(8+r*8)+'" r="1.6"/>';
    var g=[
      '<circle cx="82" cy="18" r="34" fill="none" stroke="'+c+'" stroke-width="1.4" opacity=".35"/><circle cx="82" cy="18" r="22" fill="none" stroke="'+c+'" stroke-width="1.4" opacity=".35"/><circle cx="82" cy="18" r="10" fill="'+c+'" opacity=".25"/>',
      '<path d="M-10 30L30 -10M-10 60L60 -10M-10 90L90 -10M10 110L110 10M40 110L110 40M70 110L110 70" stroke="'+c+'" stroke-width="1.6" opacity=".22" fill="none"/>',
      '<circle cx="20" cy="85" r="38" fill="'+c+'" opacity=".16"/><circle cx="88" cy="20" r="14" fill="'+c+'" opacity=".22"/>',
      '<g fill="'+c+'" opacity=".3">'+dots+'</g>',
      '<path d="M0 78Q25 62 50 78T100 78V100H0Z" fill="'+c+'" opacity=".16"/><path d="M0 90Q25 74 50 90T100 90V100H0Z" fill="'+c+'" opacity=".2"/>',
      '<path d="M70 0H100V40Z" fill="'+c+'" opacity=".22"/><path d="M0 100V62L38 100Z" fill="'+c+'" opacity=".18"/>'
    ];
    return '<svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice" aria-hidden="true" style="position:absolute;inset:0;width:100%;height:100%">'+g[i%6]+'</svg>';
  }
  function cover(x,i,mode){
    var d=document.createElement('div'), pc=PAL[i%PAL.length];
    d.className='cover'+(mode?' '+mode:'');d.style.background=pc[0];d.style.color=pc[1];
    d.insertAdjacentHTML('afterbegin',deco(i,pc[1]));
    var nm=document.createElement('div');nm.className='cn';nm.textContent=x.n;nm.style.fontFamily='"'+x.f+'",sans-serif';
    d.appendChild(nm);
    return d;
  }
  function tile(x,i,mode){
    var b=document.createElement('button');b.type='button';b.className='tile';
    var price=x.p||'$21';
    b.setAttribute('aria-label',x.n+', '+price+'. View details');
    b.appendChild(cover(x,i,mode));
    var ti=document.createElement('span');ti.className='ti';
    var tn=document.createElement('span');tn.className='tn';tn.textContent=x.n;
    var tp=document.createElement('span');tp.className='tp';tp.textContent=price;
    ti.appendChild(tn);ti.appendChild(tp);b.appendChild(ti);
    b.addEventListener('click',function(){openD(x)});
    return b;
  }
  var grid=document.getElementById('grid'), cartBtn=document.getElementById('cart'), n=0;
  function upd(d){n+=d;cartBtn.textContent='Cart ('+n+')'}
  var TY=[['','All'],['serif','Serif'],['sans','Sans Serif'],['script','Script'],['brush','Brush'],['display','Display']], chips=document.getElementById('tchips'), curT='';
  function renderGrid(){
    grid.textContent='';
    var any=false;
    fonts.forEach(function(x,fi){if(!curT||x.t===curT){grid.appendChild(tile(x,fi));any=true}});
    chips.querySelectorAll('button').forEach(function(b){b.setAttribute('aria-pressed',b.getAttribute('data-t')===curT?'true':'false')});
  }
  function setType(t){curT=t;renderGrid()}
  TY.forEach(function(y){var b=document.createElement('button');b.type='button';b.textContent=y[1];b.setAttribute('data-t',y[0]);b.addEventListener('click',function(){setType(y[0])});chips.appendChild(b)});
  renderGrid();
  document.querySelectorAll('a[data-t]').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();setType(a.getAttribute('data-t'));if(location.hash!=='#rilis')location.hash='#rilis';else document.getElementById('rilis').scrollIntoView()})});
  var pop=document.getElementById('pop');
  pops.forEach(function(x,j){pop.appendChild(tile(x,fonts.length+j,'wide'))});
  var LIC=[
    {k:'Standard License',p:'$21',d:'For print design and documents on a computer.'},
    {k:'Webfont License',p:'$40',d:'For websites, with WOFF2 files.'},
    {k:'Professional License',p:'$259',d:'For commercial branding and larger projects.'},
    {k:'Extended License',p:'$450',d:'For products, merchandise, and wider distribution.'},
    {k:'Corporate License',p:'$1999',d:'For large companies and team-wide use.'}
  ], carted={}, dlg=document.getElementById('dlg');
  var SL=8;
  function slide(x,i,k){
    var pc=PAL[i%PAL.length], inv=k%2===1, bg=inv?pc[1]:pc[0], fg=inv?pc[0]:pc[1], ff='"'+x.f+'",sans-serif';
    var d=document.createElement('div');d.className='sl';d.style.background=bg;d.style.color=fg;
    d.insertAdjacentHTML('afterbegin',deco(i+k,fg));
    function t(cls,txt,host){var e=document.createElement('div');e.className='t '+cls;e.style.fontFamily=ff;e.textContent=txt;(host||d).appendChild(e);return e}
    if(k===0){t('t1',x.n)}
    else if(k===1){t('t2','ABCDEFGHIJKLM\nNOPQRSTUVWXYZ')}
    else if(k===2){t('t3','abcdefghijklm\nnopqrstuvwxyz\n0123456789')}
    else if(k===3){var w=document.createElement('div');w.style.position='relative';d.appendChild(w);t('t4','Play Hard.\nLook Sharp.',w);t('t6','NEW TYPEFACE: '+x.n.toUpperCase(),w)}
    else if(k===4){t('t5','ŽžŠŒšŸÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßàáâãäåæçèéêëìíîïñòóôõöøùúûüýÿ')}
    else if(k===5){var bd=document.createElement('div');bd.className='bd';d.appendChild(bd);t('t3',x.n,bd);t('t6','EST. 2026',bd)}
    else if(k===6){var lb=document.createElement('div');lb.className='lb';d.appendChild(lb);t('t4','Handmade',lb);t('t6','QUALITY GOODS',lb)}
    else{t('t5','The quick brown fox\njumps over\nthe lazy dog.')}
    return d;
  }
  function gallery(x,ci){
    var gm=document.getElementById('dgm'), th=document.getElementById('dth'), cur=0, btns=[];
    th.textContent='';
    function show(k){
      cur=(k+SL)%SL;
      gm.textContent='';
      var sd=slide(x,ci,cur);sd.setAttribute('role','img');sd.setAttribute('aria-label','Preview '+(cur+1)+' of '+SL+' for '+x.n);
      gm.appendChild(sd);
      btns.forEach(function(b,j){b.setAttribute('aria-pressed',j===cur?'true':'false')});
    }
    for(var k=0;k<SL;k++){(function(k){
      var b=document.createElement('button');b.type='button';b.className='th';
      b.setAttribute('aria-label','Show image '+(k+1)+' of '+SL);
      b.appendChild(slide(x,ci,k));
      b.addEventListener('click',function(){show(k)});
      th.appendChild(b);btns.push(b);
    })(k)}
    document.getElementById('dgp').onclick=function(){show(cur-1)};
    document.getElementById('dgn').onclick=function(){show(cur+1)};
    show(0);
  }
  var USES=['Print and packaging','Logo and branding','Websites','Apps and software','Merchandise','Broadcast and film'];
  var MATRIX={'Standard License':[1,1,0,0,0,0],'Webfont License':[0,0,1,0,0,0],'Professional License':[1,1,1,1,0,0],'Extended License':[1,1,1,1,1,0],'Corporate License':[1,1,1,1,1,1]};
  function openD(x){
    var tx=document.getElementById('dtx'), ds=document.getElementById('ds'), dl=document.getElementById('dl'), dso=document.getElementById('dso'), dlo=document.getElementById('dlo');
    var fam='"'+x.f+'",sans-serif';
    document.getElementById('dn').textContent=x.n;
    var ci=x.pi!==undefined?x.pi:fonts.indexOf(x);if(ci<0)ci=fonts.length+pops.indexOf(x);
    document.getElementById('dlsec').hidden=!!x.free;document.getElementById('dusec').hidden=!!x.free;document.getElementById('dfree').hidden=!x.free;
    gallery(x,ci);
    document.getElementById('dm').textContent=(x.c||'Popular')+(x.d?' · '+x.d:'');
    tx.style.fontFamily=fam;
    function u(){tx.style.fontSize=ds.value+'px';tx.style.letterSpacing=(dl.value/100)+'em';dso.textContent=ds.value+' px';dlo.textContent=dl.value}
    ds.oninput=u;dl.oninput=u;u();
    var dg=document.getElementById('dg');dg.textContent='';
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789&@#?!'.split('').forEach(function(ch){var s=document.createElement('span');s.textContent=ch;s.style.fontFamily=fam;dg.appendChild(s)});
    var nm=x.n, cat=(x.c||'display').toLowerCase();
    document.getElementById('dpd').textContent=x.desc||('Introducing our new product, '+nm+', a '+cat+' typeface. '+nm+' is good for logotype, label, badge, headline, signature, packaging and more.');
    function fill(id,arr){var el=document.getElementById(id);el.textContent='';arr.forEach(function(v){var li=document.createElement('li');li.textContent=v;el.appendChild(li)})}
    fill('dft',['Uppercase','Lowercase','Number','Punctuation','Multilingual','PUA Encode','OpenType']);
    fill('dfl',[nm+'.otf',nm+'.ttf']);
    var tg=document.getElementById('dtg');tg.textContent='';
    [cat,'display','logotype','headline','packaging','badge'].filter(function(v,i,a){return a.indexOf(v)===i}).forEach(function(v){var sp=document.createElement('span');sp.textContent=v;tg.appendChild(sp)});
    var us=document.getElementById('dus');us.textContent='';
    var hr=document.createElement('tr');['Usage'].concat(LIC.map(function(l){return l.k.replace(' License','')})).forEach(function(v){var th=document.createElement('th');th.textContent=v;hr.appendChild(th)});us.appendChild(hr);
    USES.forEach(function(u,i){var tr=document.createElement('tr');var td=document.createElement('td');td.textContent=u;tr.appendChild(td);LIC.forEach(function(l){var c=document.createElement('td');c.textContent=MATRIX[l.k][i]?'Yes':'\u2014';tr.appendChild(c)});us.appendChild(tr)});
    var lic=document.getElementById('dlic');lic.textContent='';
    LIC.forEach(function(l){
      var key=x.n+'|'+l.k, row=document.createElement('div');row.className='lic';
      var t=document.createElement('div'), h=document.createElement('h3'), d=document.createElement('p');
      h.textContent=l.k+' · '+l.p;d.textContent=l.d;t.appendChild(h);t.appendChild(d);
      var bt=document.createElement('button');bt.type='button';
      function paint(){var on=!!carted[key];bt.setAttribute('aria-pressed',on?'true':'false');bt.textContent=on?'In cart':'Add to cart'}
      paint();
      bt.addEventListener('click',function(){if(carted[key]){delete carted[key];upd(-1)}else{carted[key]=1;upd(1)}paint()});
      row.appendChild(t);row.appendChild(bt);lic.appendChild(row);
    });
    if(!dlg.open)dlg.showModal();
  }
  document.getElementById('dx').addEventListener('click',function(){dlg.close()});
  dlg.addEventListener('click',function(e){if(e.target===dlg)dlg.close()});
  var LT=[
    {k:'Standard License',b:'Freelancers and small projects.',
     can:['Install on 1 user’s computers (up to 2 devices)','Use in print design and packaging','Use in logos and branding for your own or client work','Share your designs on social media'],
     cant:['Use on websites or in web apps','Embed in apps or software','Sell products that feature the font','Use in broadcast or film']},
    {k:'Webfont License',b:'Websites that need the font online.',
     can:['Use on 1 website','Embed with @font-face','Keep using it for the life of the site'],
     cant:['Use in print or packaging','Use in logos','Embed in apps or software','Use in broadcast or film']},
    {k:'Professional License',b:'Studios and growing teams.',
     can:['Up to 5 users','Print, packaging, logos, and branding','Websites and web apps','Embed in apps and software'],
     cant:['Sell products that feature the font','Use in broadcast or film']},
    {k:'Extended License',b:'Brands that sell products.',
     can:['Up to 20 users','Everything in Professional','Sell products and merchandise that feature the font'],
     cant:['Use in broadcast or film']},
    {k:'Corporate License',b:'One company or brand, without limits.',
     can:['Unlimited users and installs within the company','Everything in Extended','Use in TV, film, and motion graphics'],
     cant:['Use for a second company or brand']}
  ];
  var lpl=document.getElementById('lpl');
  LT.forEach(function(t,ti){
    var row=document.createElement('section');row.className='lrow';
    var a=document.createElement('div');
    var h=document.createElement('h2');h.textContent=t.k;
    var pc=document.createElement('p');pc.className='pc';pc.textContent=LIC[ti].p;
    var bf=document.createElement('p');bf.className='bf';bf.textContent=t.b;
    a.appendChild(h);a.appendChild(pc);a.appendChild(bf);
    function col(title,items,extra){
      var c=document.createElement('div');var h3=document.createElement('h3');h3.textContent=title;c.appendChild(h3);
      var ul=document.createElement('ul');
      items.concat(extra||[]).forEach(function(v){var li=document.createElement('li');li.textContent=v;ul.appendChild(li)});
      c.appendChild(ul);return c;
    }
    row.appendChild(a);
    row.appendChild(col('You can',t.can));
    row.appendChild(col('You can’t',t.cant,['Share or resell the font files']));
    lpl.appendChild(row);
  });
  var FREE=[
    {n:'Plain Sans',t:'sans',c:'Sans serif',f:'Bricolage Grotesque'},
    {n:'Offset',t:'sans',c:'Sans serif',f:'Syne'},
    {n:'Reed',t:'serif',c:'Serif',f:'Fraunces'},
    {n:'Folio',t:'serif',c:'Serif',f:'Instrument Serif'},
    {n:'Bold Wide',t:'display',c:'Display',f:'Unbounded'},
    {n:'Brush Note',t:'display',c:'Display',f:'Permanent Marker'}
  ];
  FREE.forEach(function(x,j){x.free=true;x.p='Free';x.d='Free for personal use';x.pi=fonts.length+pops.length+j});
  var frl=document.getElementById('frl');
  [['sans','Sans Serif'],['serif','Serif'],['display','Display']].forEach(function(g){
    var sec=document.createElement('section');sec.className='fgrp';
    var h=document.createElement('h2');h.textContent=g[1];sec.appendChild(h);
    var gr=document.createElement('div');gr.className='grid';
    FREE.forEach(function(x){if(x.t===g[0])gr.appendChild(tile(x,x.pi))});
    sec.appendChild(gr);frl.appendChild(sec);
  });
  document.getElementById('clogo').src=document.querySelector('.logo img').src;
  var cf=document.getElementById('cf');
  cf.addEventListener('submit',function(e){
    e.preventDefault();
    var nm=document.getElementById('cf-name').value.trim();
    document.getElementById('cf-status').textContent='Thank you, '+nm+'. We’ve received your message and will reply within 2 business days.';
    cf.reset();
  });
  function chk(el,errId,msg){
    var er=document.getElementById(errId);
    if(!el.value.trim()){er.textContent=msg;el.setAttribute('aria-invalid','true');return false}
    er.textContent='';el.removeAttribute('aria-invalid');return true;
  }
  document.getElementById('lgf').addEventListener('submit',function(e){
    e.preventDefault();
    var u=document.getElementById('lg-user'), pw=document.getElementById('lg-pass'), st=document.getElementById('lg-status');
    var a=chk(u,'lg-user-err','Enter your username or email address.');
    var b=chk(pw,'lg-pass-err','Enter your password.');
    if(!a||!b){st.textContent='';(a?pw:u).focus();return}
    st.textContent='Log in isn’t connected yet. This page is a design preview.';
  });
  document.getElementById('rsf').addEventListener('submit',function(e){
    e.preventDefault();
    var u=document.getElementById('rs-user'), st=document.getElementById('rs-status');
    if(!chk(u,'rs-user-err','Enter your username or email address.')){st.textContent='';u.focus();return}
    st.textContent='If an account matches, we’ll email you a link to create a new password.';
    u.value='';
  });
  var PG={'#licensing':['licpage','Licensing'],'#free':['freepage','Free fonts'],'#contact':['contactpage','Contact'],'#login':['loginpage','Log in']};
  var home=document.getElementById('home');
  function route(){
    var h=location.hash, cur=PG[h];
    home.hidden=!!cur;
    Object.keys(PG).forEach(function(k){document.getElementById(PG[k][0]).hidden=k!==h});
    document.title=cur?cur[1]+' — Vroz Studio':'Vroz Studio — Font Shop';
    if(cur){window.scrollTo(0,0)}
    else{var id=h.slice(1), el=id&&document.getElementById(id);if(el)el.scrollIntoView()}
  }
  window.addEventListener('hashchange',route);route();
  document.getElementById('nf').addEventListener('submit',function(e){
    e.preventDefault();
    document.getElementById('msg').textContent='Thank you. You are subscribed.';
    document.getElementById('em').value='';
  });
})();
