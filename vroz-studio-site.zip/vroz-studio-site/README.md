# Vroz Studio — Font Shop

Situs toko font statis (HTML, CSS, JavaScript tanpa framework) untuk Vroz Studio.
Halaman: beranda dengan katalog, detail font (galeri, lisensi), Free fonts,
Licensing, Contact, dan Log in.

## Struktur folder

```
vroz-studio-site/
├── index.html          Struktur halaman semua bagian
├── style.css           Seluruh tampilan (warna ada di :root)
├── script.js           Data font, katalog, dialog detail, pindah halaman
├── README.md
├── .gitignore
└── assets/
    ├── images/         logo-header.png, logo-footer.png
    ├── fonts/          Taruh file font Anda sendiri di sini (.woff2)
    └── icons/          favicon.svg
```

## Cara membuka

Klik dua kali `index.html`. Tidak perlu instalasi atau server.
Font contoh dimuat dari Google Fonts, jadi butuh koneksi internet.

## Yang paling sering diedit

| Yang ingin diubah | Di mana |
| --- | --- |
| Daftar font, nama, kategori | `script.js` → `var fonts=[` |
| Font populer | `script.js` → `var pops=[` |
| Font gratis | `script.js` → `var FREE=[` |
| Harga lisensi | `script.js` → `var LIC=[` |
| Syarat tiap lisensi (halaman Licensing) | `script.js` → `var LT=[` |
| Tabel pemakaian lisensi di detail font | `script.js` → `var MATRIX=` dan `var USES=` |
| Warna | `style.css` → blok `:root{` |
| Teks hero, menu, footer | `index.html` |
| Logo | ganti file di `assets/images/` dengan nama yang sama |

Kunci `f` pada tiap font adalah nama font-family di CSS.

## Memakai font Anda sendiri

1. Simpan file font (disarankan `.woff2`) di `assets/fonts/`.
2. Tambahkan `@font-face` di bagian atas `style.css` (contoh ada di komentar).
3. Ganti nilai `f` pada font di `script.js` dengan nama font-family tersebut.
4. Hapus tautan Google Fonts di `index.html` jika tidak dipakai lagi.

## Yang belum berfungsi (masih tampilan)

- **Keranjang dan checkout:** tombol hanya menghitung jumlah.
- **Form Contact, Log in, dan Reset password:** belum mengirim data atau terhubung ke akun.
  Sambungkan ke layanan form (mis. Formspree, Netlify Forms) atau sistem akun.
- **Tombol "Download free font":** belum menautkan ke file.
- **Halaman About, Blog, FAQ, Privacy Policy, Terms of Service, Refund Policy, Cookie Policy:** tautannya masih kosong.
- **Isi contoh:** nama font ("Vroz …"), harga, syarat lisensi, tabel pemakaian, dan
  jawaban waktu balas ("2 business days") harus diganti dengan data asli sebelum tayang.
- **Logo pembayaran** di footer adalah versi sederhana. Pakai aset resmi dari
  masing-masing penyedia dan tampilkan hanya metode yang benar-benar Anda terima.

## Menayangkan situs

Unggah seluruh folder ke hosting statis, misalnya Netlify Drop, GitHub Pages,
atau Cloudflare Pages.

## Catatan

- Halaman berpindah lewat hash (`#licensing`, `#free`, `#contact`, `#login`),
  jadi tidak perlu server khusus.
- Mode terang dan gelap mengikuti pengaturan perangkat.
